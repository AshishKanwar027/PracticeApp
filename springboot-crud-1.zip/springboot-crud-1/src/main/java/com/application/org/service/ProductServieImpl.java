package com.application.org.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.org.entity.Product;
import com.application.org.exception.NoProductFoundException;
import com.application.org.repo.ProductRepository;


@Service
public class ProductServieImpl implements IProductService{
	
	@Autowired
	ProductRepository prodRepo;
	
	@Override
	public String saveProduct(Product product) {
		// TODO Auto-generated method stub
		prodRepo.save(product);
		return "Product id:"+product.getProdId()+" is saved successfully" ;
	
		
	}

	@Override
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return prodRepo.findAll();	
		}

	@Override
	public Product getProductById(Long prodId) {
		// TODO Auto-generated method stub
		return prodRepo.findById(prodId).get();

	}

	@Override
	public String deleteProductById(Long prodId) {
		// TODO Auto-generated method stub
		boolean delete=false;
		if(prodRepo.existsById(prodId)) {
			prodRepo.deleteById(prodId);
			delete=true;
			
		}
		return "Product with Id: "+prodId+" deleted status"+delete;
	
	}

	@Override
	public Product updateProduct(Long prodId, Product product) throws NoProductFoundException {
		// TODO Auto-generated method stub
	java.util.Optional<Product> existing= prodRepo.findById(prodId);
			Product existProduct=null;
		if(existing.isPresent()) {
			 existProduct=existing.get();
			existProduct.setProdName(product.getProdName());
			existProduct.setPrice(product.getPrice());
			existProduct.setDesc(product.getDesc());
			
			prodRepo.save(existProduct);
		}
		if(existProduct==null) {
			throw new NoProductFoundException("Product not Found");
		}
		return existProduct;
	}

}
