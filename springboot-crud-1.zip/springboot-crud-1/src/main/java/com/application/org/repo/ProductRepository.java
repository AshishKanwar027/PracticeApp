package com.application.org.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.application.org.entity.Product;

public interface ProductRepository extends MongoRepository<Product, Long>{

}
