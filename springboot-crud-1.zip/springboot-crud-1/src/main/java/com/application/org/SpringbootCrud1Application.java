package com.application.org;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootCrud1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootCrud1Application.class, args);
	}

}
