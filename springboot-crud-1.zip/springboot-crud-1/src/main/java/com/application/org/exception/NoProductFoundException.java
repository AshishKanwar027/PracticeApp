package com.application.org.exception;

public class NoProductFoundException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoProductFoundException(String message) {
		super(message);
	}

}
