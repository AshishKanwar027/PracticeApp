package com.application.org.service;

import java.util.List;

import com.application.org.entity.Product;
import com.application.org.exception.NoProductFoundException;

public interface IProductService {
	
	String saveProduct(Product product);
	List<Product> getAllProduct();
	Product getProductById(Long prodId);
	String deleteProductById(Long prodId);
	Product updateProduct(Long prodId, Product product) throws NoProductFoundException;
}
